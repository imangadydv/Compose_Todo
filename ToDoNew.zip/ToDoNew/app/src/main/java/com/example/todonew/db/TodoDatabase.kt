package com.example.todonew.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters


@Database(entities = [ToDo::class], version = 1)
@TypeConverters(Converter::class)
abstract class TodoDatabase:RoomDatabase() {
              companion object{
                  const val NAME ="Todo_DB"
              }
    abstract fun getTodoDao():TodoDao

}