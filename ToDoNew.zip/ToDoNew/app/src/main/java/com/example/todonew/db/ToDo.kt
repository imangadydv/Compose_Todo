package com.example.todonew.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "TODO")
data class ToDo(
    @PrimaryKey (autoGenerate = true)
    var id:Int=0,
    var title:String,
    var createdAt:Date
)
